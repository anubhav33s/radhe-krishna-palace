require('dotenv').config();
const path = require('path');
const fs = require('fs');
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const helmet = require('helmet');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MONGODB_URI = String(process.env.MONGODB_URI || '').trim();
const JWT_SECRET = process.env.JWT_SECRET || 'radhe-krishna-palace-local-secret-change-me';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const REQUIRE_MONGODB = String(process.env.REQUIRE_MONGODB || '').toLowerCase() === 'true';

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const bookingSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  data: { type: mongoose.Schema.Types.Mixed, required: true }
}, { timestamps: true });

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  role: { type: String, default: 'admin' }
}, { timestamps: true });

const Booking = mongoose.model('Booking', bookingSchema);
const User = mongoose.model('User', userSchema);

const dataDir = path.join(__dirname, 'data');
const localFile = path.join(dataDir, 'bookings.json');
let dbMode = 'local';

function ensureLocalStore() {
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(localFile)) fs.writeFileSync(localFile, JSON.stringify({ bookings: [] }, null, 2), 'utf8');
}
function readLocalBookings() {
  ensureLocalStore();
  try {
    const obj = JSON.parse(fs.readFileSync(localFile, 'utf8'));
    return Array.isArray(obj.bookings) ? obj.bookings : [];
  } catch {
    return [];
  }
}
function writeLocalBookings(bookings) {
  ensureLocalStore();
  fs.writeFileSync(localFile, JSON.stringify({ bookings }, null, 2), 'utf8');
}

function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Authentication required' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Session expired. Please log in again.' });
  }
}

async function getBookings() {
  if (dbMode === 'mongo') {
    const docs = await Booking.find().lean();
    return docs.map(x => x.data);
  }
  return readLocalBookings();
}

async function replaceBookings(bookings) {
  if (dbMode === 'mongo') {
    await Booking.deleteMany({});
    if (bookings.length) {
      const docs = bookings.map((b, i) => ({
        id: String(b.id || `${Date.now()}-${i}-${Math.random().toString(36).slice(2, 8)}`),
        data: b
      }));
      await Booking.insertMany(docs, { ordered: true });
    }
  } else {
    writeLocalBookings(bookings);
  }
}

app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    database: dbMode === 'mongo' ? 'MongoDB Atlas/MongoDB' : 'Local JSON fallback',
    shared: dbMode === 'mongo'
  });
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const username = String(req.body.username || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (username !== 'admin' || password !== ADMIN_PASSWORD) {
      return res.status(401).json({ error: 'Incorrect username or password.' });
    }
    const token = jwt.sign(
      { username: 'admin', role: 'admin' },
      JWT_SECRET,
      { expiresIn: '12h' }
    );
    res.json({ token, username: 'admin', role: 'admin' });
  } catch {
    res.status(500).json({ error: 'Login failed' });
  }
});

app.get('/api/bookings', auth, async (req, res) => {
  try {
    res.json(await getBookings());
  } catch (e) {
    res.status(500).json({ error: 'Could not load bookings', detail: e.message });
  }
});

app.put('/api/bookings', auth, async (req, res) => {
  try {
    const bookings = Array.isArray(req.body.bookings) ? req.body.bookings : [];
    await replaceBookings(bookings);
    res.json({ ok: true, count: bookings.length, database: dbMode });
  } catch (e) {
    res.status(500).json({ error: 'Could not save bookings', detail: e.message });
  }
});

app.get('/api/backup', auth, async (req, res) => {
  try {
    res.json({ exportedAt: new Date().toISOString(), version: 3, bookings: await getBookings() });
  } catch (e) {
    res.status(500).json({ error: 'Could not export backup' });
  }
});

app.post('/api/backup', auth, async (req, res) => {
  try {
    if (!Array.isArray(req.body.bookings)) return res.status(400).json({ error: 'Invalid backup file' });
    await replaceBookings(req.body.bookings);
    res.json({ ok: true, count: req.body.bookings.length });
  } catch (e) {
    res.status(500).json({ error: 'Could not restore backup', detail: e.message });
  }
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

async function start() {
  if (MONGODB_URI) {
    console.log('Connecting to MongoDB...');
    try {
      await mongoose.connect(MONGODB_URI, { serverSelectionTimeoutMS: 8000 });
      dbMode = 'mongo';
      console.log('MongoDB connected.');
    } catch (err) {
      console.warn('\nMongoDB connection failed:', err.message);
      if (REQUIRE_MONGODB) throw err;
      console.warn('Starting in LOCAL JSON mode so the website still works.');
      console.warn('For shared multi-device data, put your MongoDB Atlas URI in .env and restart.\n');
    }
  } else {
    if (REQUIRE_MONGODB) throw new Error('MONGODB_URI is required when REQUIRE_MONGODB=true.');
    console.log('No MONGODB_URI found. Starting in LOCAL JSON mode.');
    console.log('For shared multi-device data, add MONGODB_URI to .env and restart.\n');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Website running: http://localhost:${PORT}`);
    console.log(`Database mode: ${dbMode === 'mongo' ? 'MongoDB (shared when deployed)' : 'Local JSON (this PC only)'}`);
    console.log('Admin login: admin / ' + (ADMIN_PASSWORD === 'admin123' ? 'admin123' : 'your ADMIN_PASSWORD from .env'));
  });
}

start().catch(err => {
  console.error('STARTUP ERROR:', err.message);
  process.exit(1);
});
