# Radhe Krishna Palace — MongoDB Atlas + Render Deployment

This project is ready for a public Render deployment with MongoDB Atlas as the shared database.

## 1. MongoDB Atlas
1. Create/sign in to MongoDB Atlas: https://www.mongodb.com/atlas
2. Create a Free M0 cluster.
3. Create a Database User and save the username/password.
4. Network Access: add an IP access rule. For Render, the simplest setup is `0.0.0.0/0`; use stronger network restrictions if your deployment/security setup supports them.
5. Cluster > Connect > Drivers > Node.js and copy the `mongodb+srv://...` URI.
6. Replace `<password>` with the database user's password. If the password contains reserved URI characters such as `@`, encode them (for example `@` becomes `%40`).

## 2. GitHub
Create a private GitHub repository and upload ALL files in this folder. Do NOT upload `.env`.

## 3. Render
1. Open https://render.com/
2. New > Web Service.
3. Connect the GitHub repository.
4. Render should use:
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Health Check: `/api/health`
5. Add Environment Variables:
   - `MONGODB_URI` = your Atlas `mongodb+srv://...` connection string
   - `JWT_SECRET` = a long random secret
   - `ADMIN_PASSWORD` = your desired admin password
   - `REQUIRE_MONGODB` = `true`
   - `NODE_ENV` = `production`
6. Deploy.

Render gives the service a public `onrender.com` URL. Open that URL on phone/laptop/PC. All devices use the same Render server and Atlas database.

## 4. Verify
Open:
`https://YOUR-SERVICE.onrender.com/api/health`

Expected:
`{"ok":true,"database":"MongoDB Atlas/MongoDB","shared":true}`

Then open the main public URL and log in with:
- Username: `admin`
- Password: the value you set for `ADMIN_PASSWORD`

## Security
- Never commit `.env` or the Atlas connection string to GitHub.
- Change the default admin password before production.
- Use a strong JWT secret.
- If you change Atlas network rules, make sure Render can still reach the database.
